# Accessible Personal Portfolio

A multi-page personal portfolio starter built with semantic HTML5, responsive CSS, and a small amount of vanilla JavaScript. It is intended as an internship project focused on accessibility, SEO, and maintainable front-end structure.

## Pages

- `index.html` — homepage and featured projects
- `about.html` — profile, approach, and skills
- `projects.html` — project summaries
- `contact.html` — contact details and external profiles

## Technologies

- Semantic HTML5 landmarks and page structure
- CSS custom properties and responsive layouts
- Vanilla JavaScript for the mobile navigation
- Keyboard focus styles, skip link, and reduced-motion support
- Page-specific titles and meta descriptions
- `robots.txt` and `sitemap.xml` templates

## Run locally

No build step is required.

1. Download or clone this repository.
2. Open `index.html` in a browser, or run a local static server from the project folder, for example:

   ```bash
   python -m http.server 8000
   ```

3. Visit `http://localhost:8000`.

## Personalize before submission

Search the project for `Alex Morgan`, `hello@example.com`, and `example.com`. Replace these with your real information. Update project descriptions to reflect work you actually completed. The contact links are examples; no backend contact form is configured.

The Google Fonts import is optional; if you need a fully self-hosted/offline version, remove the `@import` line in the stylesheet and rely on the system fallbacks.

## Accessibility and quality checks

Automated results can vary by Lighthouse version, browser, and hosting environment. A perfect score is a target, not a guarantee or proof of WCAG conformance.

### Lighthouse

1. Serve the site locally or deploy it.
2. Open Chrome DevTools → Lighthouse.
3. Run **Accessibility** and **SEO** audits for each page, preferably on both mobile and desktop.
4. Fix all reported issues and record the final scores and audit date in your internship report.

### Manual checks

- Navigate all links and the mobile menu using only the keyboard.
- Confirm the skip link appears on focus and moves to the main content.
- Check focus indicators and logical focus order.
- Test browser zoom at 200% and 400%.
- Check text and UI contrast with a contrast analyzer.
- Test with a screen reader (for example NVDA, VoiceOver, or TalkBack).
- Verify headings, page titles, links, and any added image alternatives.
- Test reduced-motion settings and a narrow mobile viewport.
- Check every page for broken links and console errors.

## SEO before deployment

- Replace `example.com` in `sitemap.xml` and `robots.txt` with your real canonical domain.
- Add canonical URL metadata to each page after the final domain is known.
- Submit the sitemap in Google Search Console if appropriate.
- Confirm the deployed pages are crawlable and return successful HTTP responses.

## Suggested GitHub repository description

`Accessible multi-page portfolio built with semantic HTML5, responsive CSS, WCAG-informed patterns, and SEO fundamentals.`

## License

Choose a license suitable for your intended use before publishing.
