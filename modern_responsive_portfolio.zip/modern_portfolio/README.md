# Alex Morgan — Responsive Developer Portfolio

A polished, responsive portfolio concept built with semantic HTML5, CSS3, and vanilla JavaScript.

## Features
- CSS Grid for page sections and project layouts
- Flexbox for navigation, cards, metadata, and alignment
- Mobile-first responsive breakpoints for phones, tablets, and desktops
- Light/dark theme using CSS custom properties, saved in `localStorage`
- Responsive mobile navigation with accessible state labels
- Active navigation state based on the current section
- CSS-only project artwork and animated details
- Reduced-motion preference support
- Semantic landmarks, descriptive labels, and keyboard-accessible controls
- No build tools or frameworks required

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. For best results, use VS Code with the Live Server extension.

## Personalize before publishing
This is a demo portfolio. Replace the sample name, bio, stats, project details, contact email (`hello@example.com`), and social links with your own information. The three project cards are illustrative concept projects, not claims of completed client work.

## Files
- `index.html` — semantic content and layout
- `style.css` — theme tokens, visual styling, Grid/Flexbox, responsive rules, and animations
- `script.js` — theme toggle, mobile menu, active section links, and dynamic footer year
